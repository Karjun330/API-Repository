package config;

import org.aeonbits.owner.Config;

@Config.LoadPolicy(Config.LoadType.MERGE)
@Config.Sources({
        "system:properties",
        "system:env",
        "file:${user.dir}/src/test/resources/config.properties"
})
public interface FrameworkConfig extends Config {
    String hotsUri();
    String hotsUserName();
    String hotPassword();
    String msqUri();
    String msqUserName();
    String msqPassword();
    String excelPath();
    String excelSheet();
}
