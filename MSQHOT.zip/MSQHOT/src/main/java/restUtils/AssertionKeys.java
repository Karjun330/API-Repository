package restUtils;



public class AssertionKeys {
    private String property;
    private String dTelValue;
    private String tekSavvyValue;
    private String msqValue;
    private String result;


    public String getProperty() {
        return this.property;
    }

    public String getDTelValue() {
        return this.dTelValue;
    }

    public String getTekSavvyValue() {
        return this.tekSavvyValue;
    }

    public String getMsqValue() {
        return this.msqValue;
    }

    public String getResult() {
        return this.result;
    }

    public AssertionKeys(String property, String dTelValue, String tekSavvyValue, String msqValue, String result) {
        this.property = property;
        this.dTelValue = dTelValue;
        this.tekSavvyValue = tekSavvyValue;
        this.msqValue = msqValue;
        this.result = result;
    }
}
