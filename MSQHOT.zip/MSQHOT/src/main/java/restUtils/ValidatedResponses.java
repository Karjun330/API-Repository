package restUtils;

import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import javax.xml.xpath.XPathExpressionException;
import org.w3c.dom.*;
import org.xml.sax.*;

public class ValidatedResponses {

    public static void validateAllVerificationPoints(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException {
        AssertionUtils.generateTableHeadersInReports();
        validateStreetNumber(dTelResponse, tekSavvyResponse, msqResponse);
        validateStreetName(dTelResponse, tekSavvyResponse, msqResponse);
        validateStreetType(dTelResponse, tekSavvyResponse, msqResponse);
        validateMunicipalityCity(dTelResponse, tekSavvyResponse, msqResponse);
        validateProvinceOrState(dTelResponse, tekSavvyResponse, msqResponse);
        validatePostalCode(dTelResponse, tekSavvyResponse, msqResponse);
        validateCategory(dTelResponse, tekSavvyResponse, msqResponse);
        validateQualificationID(dTelResponse, tekSavvyResponse, msqResponse);
        validateRateBand(dTelResponse, tekSavvyResponse, msqResponse);
        validateNetworkType(dTelResponse, tekSavvyResponse, msqResponse);
        validateIsBondable(dTelResponse, tekSavvyResponse, msqResponse);
        validateFibreDownloadSpeed(dTelResponse, tekSavvyResponse, msqResponse);
        validateFibreUploadSpeed(dTelResponse, tekSavvyResponse, msqResponse);
        validateCopperDownloadSpeed(dTelResponse, tekSavvyResponse, msqResponse);
        validateCopperUploadSpeed(dTelResponse, tekSavvyResponse, msqResponse);
        validateFibreTroubleIndicator(dTelResponse, tekSavvyResponse, msqResponse);
        validateCopperTroubleIndicator(dTelResponse, tekSavvyResponse, msqResponse);
        validateDownloadSpeedPb(dTelResponse, tekSavvyResponse, msqResponse);
        validateUploadSpeedPb(dTelResponse, tekSavvyResponse, msqResponse);
        validateAllGASR(dTelResponse, tekSavvyResponse, msqResponse);
        validateAllGASB(dTelResponse, tekSavvyResponse, msqResponse);
        validateAllDBSR(dTelResponse, tekSavvyResponse, msqResponse);
        validateAllDBSB(dTelResponse, tekSavvyResponse, msqResponse);

        AssertionUtils.generateTableInReport();
    }

    private static void validateStreetNumber(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {

        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//address/streetNumber";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvydocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//address/streetNumber";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvydocument, tekSavvyPath);

     //   String msqPath = "$.locationMatches.locationMatch[0].sourceAddressDetails[0].parsedStreetAddress.streetNumber";
        String msqPath = "$.locationMatches.locationMatch[0].commercialAddressDetails.parsedStreetAddress.streetNumber";
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), msqPath);

        validateEquals("StreetNumber", dtel, tekSavvy, msq);
    }

    private static void validateStreetName(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {

        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//address/streetName";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvydocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//address/streetName";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvydocument, tekSavvyPath);


      //  String msqPath = "$.locationMatches.locationMatch[0].sourceAddressDetails[0].parsedStreetAddress.streetName";
        String msqPath = "$.locationMatches.locationMatch[0].commercialAddressDetails.parsedStreetAddress.streetName";
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), msqPath);
        validateEquals("StreetName", dtel, tekSavvy, msq);
    }

    private static void validateStreetType(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {

        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//address/streetType";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvydocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//address/streetType";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvydocument, tekSavvyPath);


      //  String msqPath = "$.locationMatches.locationMatch[0].sourceAddressDetails[0].parsedStreetAddress.streetType";
        String msqPath = "$.locationMatches.locationMatch[0].commercialAddressDetails.parsedStreetAddress.streetType";
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), msqPath);
        validateEquals("StreetType", dtel, tekSavvy, msq);
    }

    private static void validateMunicipalityCity(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {


        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//address/municipalityCity";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvydocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//address/municipalityCity";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvydocument, tekSavvyPath);


        //String msqPath = "$.locationMatches.locationMatch[0].sourceAddressDetails[0].city";
        String msqPath = "$.locationMatches.locationMatch[0].commercialAddressDetails.city";
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), msqPath);

        validateEquals("MunicipalityCity", dtel, tekSavvy, msq);


    }

    private static void validateProvinceOrState(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {

        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//address/provinceOrState";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvydocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//address/provinceOrState";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvydocument, tekSavvyPath);


       // String msqPath = "$.locationMatches.locationMatch[0].sourceAddressDetails[0].province";
        String msqPath = "$.locationMatches.locationMatch[0].commercialAddressDetails.province";
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), msqPath);
        validateEquals("Province", dtel, tekSavvy, msq);

    }

    private static void validatePostalCode(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {

        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//address/postalCode";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath).replaceAll("\\s", "");

        Document tekSavvydocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//address/postalCode";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvydocument, tekSavvyPath).replaceAll("\\s", "");


        String msqPath = "$.locationMatches.locationMatch[0].commercialAddressDetails.postalCode";
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), msqPath).replaceAll("\\s", "");
        validateEquals("PostalCode", dtel, tekSavvy, msq);
    }

    private static void validateCategory(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException {

        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//servicePointCharacteristics/category";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvydocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//servicePointCharacteristics/category";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvydocument, tekSavvyPath);


        String isCopper = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.copperTerminal");
        String isFibre = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fibreTerminal");
        String str = "";
        if (isCopper.equals("Yes") && isFibre.equals("No")) {
            str = "Copper";
        } else if (isCopper.equals("No") && isFibre.equals("Yes")) {
            str = "Fibre";
        } else if (isCopper.equals("Yes") && isFibre.equals("Yes")) {
            str = "Copper Fibre";
        } else {
            str = "";
        }
        validateEquals("Category", dtel, tekSavvy, str);
    }

    private static void validateQualificationID(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//property[name='QualificationID']/value";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//property[name='QualificationID']/value";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);

        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.baseSaid");
        validateEquals("Qualification ID", dtel, tekSavvy, msq);
    }

    private static void validateRateBand(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws XPathExpressionException, ParserConfigurationException, IOException, SAXException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//property[name='RateBand']/value";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//property[name='RateBand']/value";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);

        String msqPath = "$.locationMatches.locationMatch[0].sourceAddressDetails[0].addressAttributes.attribute[?(@.name=='RateBand')].value";
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), msqPath);
        validateEquals("RateBand", dtel, tekSavvy, msq);
    }

    private static void validateNetworkType(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//property[name='NetworkType']/value";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//property[name='NetworkType']/value";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);

        String isFTTP = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttpNetwork");
        String isFTTN = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttnNetwork");
        String str = "";
        if (isFTTP.equals("Yes") && isFTTN.equals("No")) {
            str = "FTTP";
        } else if (isFTTP.equals("No") && isFTTN.equals("Yes")) {
            str = "FTTN";
        } else if (isFTTP.equals("Yes") && isFTTN.equals("Yes")) {
            str = "FTTP FTTN";
        } else {
            str = "";
        }
        validateEquals("NetworkType", dtel, tekSavvy, str);
    }

    private static void validateIsBondable(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//property[name='IsBondable']/value";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//property[name='IsBondable']/value";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);

        String isBondable = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttnPairBonding");
        String str = "";
        if (isBondable != null) {
            if (isBondable.equals("true")) {
                str = "Y";
            } else if (isBondable.toString().equals("false")) {
                str = "N";
            }
        }
        validateEquals("IsBondable", dtel, tekSavvy, str);
    }

    private static void validateFibreDownloadSpeed(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String isFibreDtel = XMLDOMUtils.parseXML(tekSavvyDocument, "//category");
        String isFibreTek = XMLDOMUtils.parseXML(dTeldocument, "//category");
        String dtel = "";
        String tekSavvy = "";
        if (isFibreDtel.trim().equals("Fibre")) {
            String dTelPath = "//property[name='DownloadSpeed']/value";
            dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);
        }
        if (isFibreTek.trim().equals("Fibre")) {
            String tekSavvyPath = "//property[name='DownloadSpeed']/value";
            tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);
        }

        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttpDataHighestDownloadSpeed");
        validateEquals("FibreDownloadSpeed", dtel, tekSavvy, msq);

    }

    private static void validateCopperDownloadSpeed(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String iSCopperDtel = XMLDOMUtils.parseXML(tekSavvyDocument, "//category");
        String isCopperTek = XMLDOMUtils.parseXML(dTeldocument, "//category");
        String dtel = "";
        String tekSavvy = "";
        if (iSCopperDtel.trim().equals("Copper")) {
            String dTelPath = "//property[name='DownloadSpeed']/value";
            dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);
        }
        if (isCopperTek.trim().equals("Copper")) {
            String tekSavvyPath = "//property[name='DownloadSpeed']/value";
            tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);
        }

        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttnDataHighestDownloadSpeed");
        validateEquals("CopperDownloadSpeed", dtel, tekSavvy, msq);

    }

    private static void validateFibreUploadSpeed(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String isFibreDtel = XMLDOMUtils.parseXML(tekSavvyDocument, "//category");
        String isFibreTek = XMLDOMUtils.parseXML(dTeldocument, "//category");
        String dtel = "";
        String tekSavvy = "";
        if (isFibreDtel.trim().equals("Fibre")) {
            String dTelPath = "//property[name='UploadSpeed']/value";
            dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);
        }
        if (isFibreTek.trim().equals("Fibre")) {
            String tekSavvyPath = "//property[name='UploadSpeed']/value";
            tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);
        }
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttpDataHighestUploadSpeed");
        validateEquals("FibreUploadSpeed", dtel, tekSavvy, msq);

    }

    private static void validateCopperUploadSpeed(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String iSCopperDtel = XMLDOMUtils.parseXML(tekSavvyDocument, "//category");
        String isCopperTek = XMLDOMUtils.parseXML(dTeldocument, "//category");
        String dtel = "";
        String tekSavvy = "";
        if (iSCopperDtel.trim().equals("Copper")) {
            String dTelPath = "//property[name='UploadSpeed']/value";
            dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);
        }
        if (isCopperTek.trim().equals("Copper")) {
            String tekSavvyPath = "//property[name='UploadSpeed']/value";
            tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);
        }
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttnDataHighestUploadSpeed");
        validateEquals("CopperUploadSpeed", dtel, tekSavvy, msq);

    }

    private static void validateFibreTroubleIndicator(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String isFibreDtel = XMLDOMUtils.parseXML(tekSavvyDocument, "//category");
        String isFibreTek = XMLDOMUtils.parseXML(dTeldocument, "//category");
        String dtel = "";
        String tekSavvy = "";
        if (isFibreDtel.trim().equals("Fibre")) {
            String dTelPath = "//property[name='TroubleIndicator']/value";
            dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);
        }
        if (isFibreTek.trim().equals("Fibre")) {
            String tekSavvyPath = "//property[name='TroubleIndicator']/value";
            tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);
        }
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttpDataStatus");
        validateEquals("FibreTroubleIndicator", dtel, tekSavvy, msq);
    }

    private static void validateCopperTroubleIndicator(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String iSCopperDtel = XMLDOMUtils.parseXML(tekSavvyDocument, "//category");
        String isCopperTek = XMLDOMUtils.parseXML(dTeldocument, "//category");
        String dtel = "";
        String tekSavvy = "";
        if (iSCopperDtel.trim().equals("Copper")) {
            String dTelPath = "//property[name='TroubleIndicator']/value";
            dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);
        }
        if (isCopperTek.trim().equals("Copper")) {
            String tekSavvyPath = "//property[name='TroubleIndicator']/value";
            tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);
        }
        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttnDataStatus");
        validateEquals("CopperTroubleIndicator", dtel, tekSavvy, msq);

    }

    private static void validateDownloadSpeedPb(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//property[name='DownloadSpeedPB']/value";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//property[name='DownloadSpeedPB']/value";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);

        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttnPbDataHighestDownloadSpeed");
        msq = msq.replace(".0", "");
        validateEquals("DownloadSpeedPb", dtel, tekSavvy, msq);
    }

    private static void validateUploadSpeedPb(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        String dTelPath = "//property[name='UploadSpeedPB']/value";
        String dtel = XMLDOMUtils.parseXML(dTeldocument, dTelPath);

        Document tekSavvyDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        String tekSavvyPath = "//property[name='UploadSpeedPB']/value";
        String tekSavvy = XMLDOMUtils.parseXML(tekSavvyDocument, tekSavvyPath);

        String msq = JSONUtils.parseJSON(msqResponse.asPrettyString(), "$.locationMatches.locationMatch[0].fttxAttributes.fttnPbDataHighestUploadSpeed");
        msq = msq.replace(".0", "");
        validateEquals("UploadSpeedPb", dtel, tekSavvy, msq);
    }

    private static void validateAllGASR(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        System.out.println("GASR: ");
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        Map<String, String> dTelProducts = XMLDOMUtils.parseGASRProductsXML(dTeldocument);
        Map<String, String> tekSavvyProducts = XMLDOMUtils.parseGASRProductsXML(tekDocument);
//        System.out.println("DTel Size : " +dTelProducts.size());
        if(dTelProducts.size()>0) {
            List<String> listDtel;
            for (String i : dTelProducts.keySet()){
//                System.out.println("ID : " + i + " Desc: " + dTelProducts.get(i) );
                listDtel = RegexUtils.getDownloadUploadSpeed(dTelProducts.get(i));
                if (listDtel == null) {
                    listDtel = new ArrayList<>();
                    listDtel.add("");
                    listDtel.add("");
                } else {
                    if (Double.parseDouble(listDtel.get(0)) < 1.00) {
                        Double d = Double.parseDouble(listDtel.get(0)) * 1000;
                        String sre = String.valueOf(d.intValue());
                        listDtel.set(0, sre);
                    } else {
                        Double d = Double.parseDouble(listDtel.get(0));
                        int val = d.intValue();
                        String sre = String.valueOf(val);
                        listDtel.set(0, sre);
                    }
                    if(listDtel.size()>1) {
                        if (Double.parseDouble(listDtel.get(1)) < 1.00) {
                            Double d = Double.parseDouble(listDtel.get(1)) * 1000;
                            String sre = String.valueOf(d.intValue());
                            listDtel.set(1, sre);
                        } else {
                            Double d = Double.parseDouble(listDtel.get(1));
                            int val = d.intValue();
                            String sre = String.valueOf(val);
                            listDtel.set(1, sre);
                        }
                    } else {
                        listDtel.add("");
                    }

                }
                if(tekSavvyProducts.containsKey(i)) {
                    String msqDownload = JSONUtils.getMQSGASRDownloadSpeed(msqResponse.asPrettyString(), listDtel.get(0));
                    String msqUpload = JSONUtils.getMQSGASRUploadSpeed(msqResponse.asPrettyString(), listDtel.get(1));
                    String msqProductId = JSONUtils.getMQSGASRProductId(msqResponse.asPrettyString(), listDtel.get(0));
                    validateEqualsProducts(i+ " Download", listDtel.get(0), listDtel.get(0), String.valueOf(msqDownload), msqProductId);
                    validateEquals("Upload", listDtel.get(1), listDtel.get(1), String.valueOf(msqUpload));
                    tekSavvyProducts.remove(i);
                } else {
                    String msqDownload = JSONUtils.getMQSGASRDownloadSpeed(msqResponse.asPrettyString(), listDtel.get(0));
                    String msqUpload = JSONUtils.getMQSGASRUploadSpeed(msqResponse.asPrettyString(), listDtel.get(1));
                    String msqProductId = JSONUtils.getMQSGASRProductId(msqResponse.asPrettyString(), listDtel.get(0));
                    validateEqualsProducts(i+" Download", listDtel.get(0), "", String.valueOf(msqDownload), msqProductId);
                    validateEquals("Upload", listDtel.get(1),"", String.valueOf(msqUpload));
                }
            }
        }



//        System.out.println("tek savvy Size : " +tekSavvyProducts.size());
        if(tekSavvyProducts.size()>0) {
            List<String> listTek;
            for (String i : tekSavvyProducts.keySet()){
//                System.out.println("ID : " + i + " Desc: " + tekSavvyProducts.get(i) );
                listTek = RegexUtils.getDownloadUploadSpeed(tekSavvyProducts.get(i));
                if (listTek == null) {
                    listTek = new ArrayList<>();
                    listTek.add("");
                    listTek.add("");
                } else {
                    if (Double.parseDouble(listTek.get(0)) < 1.00) {
                        Double d = Double.parseDouble(listTek.get(0)) * 1000;
                        String sre = String.valueOf(d.intValue());
                        listTek.set(0, sre);
                    } else {
                        Double d = Double.parseDouble(listTek.get(0));
                        int val = d.intValue();
                        String sre = String.valueOf(val);
                        listTek.set(0, sre);
                    }
                    if(listTek.size()>1) {
                        if (Double.parseDouble(listTek.get(1)) < 1.00) {
                            Double d = Double.parseDouble(listTek.get(1)) * 1000;
                            String sre = String.valueOf(d.intValue());
                            listTek.set(1, sre);
                        } else {
                            Double d = Double.parseDouble(listTek.get(1));
                            int val = d.intValue();
                            String sre = String.valueOf(val);
                            listTek.set(1, sre);
                        }
                    } else {
                        listTek.add("");
                    }

                }
                String msqDownload = JSONUtils.getMQSGASRDownloadSpeed(msqResponse.asPrettyString(), listTek.get(0));
                String msqUpload = JSONUtils.getMQSGASRUploadSpeed(msqResponse.asPrettyString(), listTek.get(1));
                String msqProductId = JSONUtils.getMQSGASRProductId(msqResponse.asPrettyString(), listTek.get(0));
                validateEqualsProducts(i+" Download", "", listTek.get(0), String.valueOf(msqDownload), msqProductId);
                validateEquals("Upload", "", listTek.get(1), String.valueOf(msqUpload));

            }
        }

    }

    private static void validateAllGASB(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        System.out.println("GASB: ");
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        Map<String, String> dTelProducts = XMLDOMUtils.parseGASBProductsXML(dTeldocument);
        Map<String, String> tekSavvyProducts = XMLDOMUtils.parseGASBProductsXML(tekDocument);
//        System.out.println("DTel Size : " +dTelProducts.size());
        if(dTelProducts.size()>0) {
            List<String> listDtel;
            for (String i : dTelProducts.keySet()){
//                System.out.println("ID : " + i + " Desc: " + dTelProducts.get(i) );
                listDtel = RegexUtils.getDownloadUploadSpeed(dTelProducts.get(i));
                if (listDtel == null) {
                    listDtel = new ArrayList<>();
                    listDtel.add("");
                    listDtel.add("");
                } else {
                    if (Double.parseDouble(listDtel.get(0)) < 1.00) {
                        Double d = Double.parseDouble(listDtel.get(0)) * 1000;
                        String sre = String.valueOf(d.intValue());
                        listDtel.set(0, sre);
                    } else {
                        Double d = Double.parseDouble(listDtel.get(0));
                        int val = d.intValue();
                        String sre = String.valueOf(val);
                        listDtel.set(0, sre);
                    }
                    if(listDtel.size()>1) {
                        if (Double.parseDouble(listDtel.get(1)) < 1.00) {
                            Double d = Double.parseDouble(listDtel.get(1)) * 1000;
                            String sre = String.valueOf(d.intValue());
                            listDtel.set(1, sre);
                        } else {
                            Double d = Double.parseDouble(listDtel.get(1));
                            int val = d.intValue();
                            String sre = String.valueOf(val);
                            listDtel.set(1, sre);
                        }
                    } else {
                        listDtel.add("");
                    }

                }
                if(tekSavvyProducts.containsKey(i)) {
                    String msqDownload = JSONUtils.getMQSGASBDownloadSpeed(msqResponse.asPrettyString(), listDtel.get(0));
                    String msqUpload = JSONUtils.getMQSGASBUploadSpeed(msqResponse.asPrettyString(), listDtel.get(1));
                    String msqProductId = JSONUtils.getMQSGASBProductId(msqResponse.asPrettyString(), listDtel.get(0));
                    validateEqualsProducts(i+ " Download", listDtel.get(0), listDtel.get(0), String.valueOf(msqDownload), msqProductId);
                    validateEquals("Upload", listDtel.get(1), listDtel.get(1), String.valueOf(msqUpload));
                    tekSavvyProducts.remove(i);
                } else {
                    String msqDownload = JSONUtils.getMQSGASBDownloadSpeed(msqResponse.asPrettyString(), listDtel.get(0));
                    String msqUpload = JSONUtils.getMQSGASBUploadSpeed(msqResponse.asPrettyString(), listDtel.get(1));
                    String msqProductId = JSONUtils.getMQSGASBProductId(msqResponse.asPrettyString(), listDtel.get(0));
                    validateEqualsProducts(i+" Download", listDtel.get(0), "", String.valueOf(msqDownload), msqProductId);
                    validateEquals("Upload", listDtel.get(1),"", String.valueOf(msqUpload));
                }
            }
        }



//        System.out.println("tek savvy Size : " +tekSavvyProducts.size());
        if(tekSavvyProducts.size()>0) {
            List<String> listTek;
            for (String i : tekSavvyProducts.keySet()){
//                System.out.println("ID : " + i + " Desc: " + tekSavvyProducts.get(i) );
                listTek = RegexUtils.getDownloadUploadSpeed(tekSavvyProducts.get(i));
                if (listTek == null) {
                    listTek = new ArrayList<>();
                    listTek.add("");
                    listTek.add("");
                } else {
                    if (Double.parseDouble(listTek.get(0)) < 1.00) {
                        Double d = Double.parseDouble(listTek.get(0)) * 1000;
                        String sre = String.valueOf(d.intValue());
                        listTek.set(0, sre);
                    } else {
                        Double d = Double.parseDouble(listTek.get(0));
                        int val = d.intValue();
                        String sre = String.valueOf(val);
                        listTek.set(0, sre);
                    }
                    if(listTek.size()>1) {
                        if (Double.parseDouble(listTek.get(1)) < 1.00) {
                            Double d = Double.parseDouble(listTek.get(1)) * 1000;
                            String sre = String.valueOf(d.intValue());
                            listTek.set(1, sre);
                        } else {
                            Double d = Double.parseDouble(listTek.get(1));
                            int val = d.intValue();
                            String sre = String.valueOf(val);
                            listTek.set(1, sre);
                        }
                    } else {
                        listTek.add("");
                    }

                }
                String msqDownload = JSONUtils.getMQSGASBDownloadSpeed(msqResponse.asPrettyString(), listTek.get(0));
                String msqUpload = JSONUtils.getMQSGASBUploadSpeed(msqResponse.asPrettyString(), listTek.get(1));
                String msqProductId = JSONUtils.getMQSGASBProductId(msqResponse.asPrettyString(), listTek.get(0));
                validateEqualsProducts(i+" Download", "", listTek.get(0), String.valueOf(msqDownload), msqProductId);
                validateEquals("Upload", "", listTek.get(1), String.valueOf(msqUpload));

            }
        }

    }

    private static void validateAllDBSR(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        System.out.println("GASB: ");
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        Map<String, String> dTelProducts = XMLDOMUtils.parseDBSRProductsXML(dTeldocument);
        Map<String, String> tekSavvyProducts = XMLDOMUtils.parseDBSRProductsXML(tekDocument);
//        System.out.println("DTel Size : " +dTelProducts.size());
        if(dTelProducts.size()>0) {
            List<String> listDtel;
            for (String i : dTelProducts.keySet()){
//                System.out.println("ID : " + i + " Desc: " + dTelProducts.get(i) );
                listDtel = RegexUtils.getDownloadUploadSpeed(dTelProducts.get(i));
                if (listDtel == null) {
                    listDtel = new ArrayList<>();
                    listDtel.add("");
                    listDtel.add("");
                } else {
                    if (Double.parseDouble(listDtel.get(0)) < 1.00) {
                        Double d = Double.parseDouble(listDtel.get(0)) * 1000;
                        String sre = String.valueOf(d.intValue());
                        listDtel.set(0, sre);
                    } else {
                        Double d = Double.parseDouble(listDtel.get(0));
                        int val = d.intValue();
                        String sre = String.valueOf(val);
                        listDtel.set(0, sre);
                    }
                    if(listDtel.size()>1) {
                        if (Double.parseDouble(listDtel.get(1)) < 1.00) {
                            Double d = Double.parseDouble(listDtel.get(1)) * 1000;
                            String sre = String.valueOf(d.intValue());
                            listDtel.set(1, sre);
                        } else {
                            Double d = Double.parseDouble(listDtel.get(1));
                            int val = d.intValue();
                            String sre = String.valueOf(val);
                            listDtel.set(1, sre);
                        }
                    } else {
                        listDtel.add("");
                    }

                }
                if(tekSavvyProducts.containsKey(i)) {
                    String msqDownload = JSONUtils.getMQSDBSRDownloadSpeed(msqResponse.asPrettyString(), listDtel.get(0));
                    String msqUpload = JSONUtils.getMQSDBSRUploadSpeed(msqResponse.asPrettyString(), listDtel.get(1));
                    String msqProductId = JSONUtils.getMQSDBSRProductId(msqResponse.asPrettyString(), listDtel.get(0));
                    validateEqualsProducts(i+ " Download", listDtel.get(0), listDtel.get(0), String.valueOf(msqDownload), msqProductId);
                    validateEquals("Upload", listDtel.get(1), listDtel.get(1), String.valueOf(msqUpload));
                    tekSavvyProducts.remove(i);
                } else {
                    String msqDownload = JSONUtils.getMQSDBSRDownloadSpeed(msqResponse.asPrettyString(), listDtel.get(0));
                    String msqUpload = JSONUtils.getMQSDBSRUploadSpeed(msqResponse.asPrettyString(), listDtel.get(1));
                    String msqProductId = JSONUtils.getMQSDBSRProductId(msqResponse.asPrettyString(), listDtel.get(0));
                    validateEqualsProducts(i+" Download", listDtel.get(0), "", String.valueOf(msqDownload), msqProductId);
                    validateEquals("Upload", listDtel.get(1),"", String.valueOf(msqUpload));
                }
            }
        }



//        System.out.println("tek savvy Size : " +tekSavvyProducts.size());
        if(tekSavvyProducts.size()>0) {
            List<String> listTek;
            for (String i : tekSavvyProducts.keySet()){
//                System.out.println("ID : " + i + " Desc: " + tekSavvyProducts.get(i) );
                listTek = RegexUtils.getDownloadUploadSpeed(tekSavvyProducts.get(i));
                if (listTek == null) {
                    listTek = new ArrayList<>();
                    listTek.add("");
                    listTek.add("");
                } else {
                    if (Double.parseDouble(listTek.get(0)) < 1.00) {
                        Double d = Double.parseDouble(listTek.get(0)) * 1000;
                        String sre = String.valueOf(d.intValue());
                        listTek.set(0, sre);
                    } else {
                        Double d = Double.parseDouble(listTek.get(0));
                        int val = d.intValue();
                        String sre = String.valueOf(val);
                        listTek.set(0, sre);
                    }
                    if(listTek.size()>1) {
                        if (Double.parseDouble(listTek.get(1)) < 1.00) {
                            Double d = Double.parseDouble(listTek.get(1)) * 1000;
                            String sre = String.valueOf(d.intValue());
                            listTek.set(1, sre);
                        } else {
                            Double d = Double.parseDouble(listTek.get(1));
                            int val = d.intValue();
                            String sre = String.valueOf(val);
                            listTek.set(1, sre);
                        }
                    } else {
                        listTek.add("");
                    }

                }
                String msqDownload = JSONUtils.getMQSDBSRDownloadSpeed(msqResponse.asPrettyString(), listTek.get(0));
                String msqUpload = JSONUtils.getMQSDBSRUploadSpeed(msqResponse.asPrettyString(), listTek.get(1));
                String msqProductId = JSONUtils.getMQSDBSRProductId(msqResponse.asPrettyString(), listTek.get(0));
                validateEqualsProducts(i+" Download", "", listTek.get(0), String.valueOf(msqDownload), msqProductId);
                validateEquals("Upload", "", listTek.get(1), String.valueOf(msqUpload));

            }
        }

    }

    private static void validateAllDBSB(Response dTelResponse, Response tekSavvyResponse, Response msqResponse) throws ParserConfigurationException, IOException, SAXException, XPathExpressionException {
        System.out.println("GASB: ");
        Document dTeldocument = XMLDOMUtils.stringToDOM(dTelResponse.asPrettyString());
        Document tekDocument = XMLDOMUtils.stringToDOM(tekSavvyResponse.asPrettyString());
        Map<String, String> dTelProducts = XMLDOMUtils.parseDBSBProductsXML(dTeldocument);
        Map<String, String> tekSavvyProducts = XMLDOMUtils.parseDBSBProductsXML(tekDocument);
//        System.out.println("DTel Size : " +dTelProducts.size());
        if(dTelProducts.size()>0) {
            List<String> listDtel;
            for (String i : dTelProducts.keySet()){
//                System.out.println("ID : " + i + " Desc: " + dTelProducts.get(i) );
                listDtel = RegexUtils.getDownloadUploadSpeed(dTelProducts.get(i));
                if (listDtel == null) {
                    listDtel = new ArrayList<>();
                    listDtel.add("");
                    listDtel.add("");
                } else {
                    if (Double.parseDouble(listDtel.get(0)) < 1.00) {
                        Double d = Double.parseDouble(listDtel.get(0)) * 1000;
                        String sre = String.valueOf(d.intValue());
                        listDtel.set(0, sre);
                    } else {
                        Double d = Double.parseDouble(listDtel.get(0));
                        int val = d.intValue();
                        String sre = String.valueOf(val);
                        listDtel.set(0, sre);
                    }
                    if(listDtel.size()>1) {
                        if (Double.parseDouble(listDtel.get(1)) < 1.00) {
                            Double d = Double.parseDouble(listDtel.get(1)) * 1000;
                            String sre = String.valueOf(d.intValue());
                            listDtel.set(1, sre);
                        } else {
                            Double d = Double.parseDouble(listDtel.get(1));
                            int val = d.intValue();
                            String sre = String.valueOf(val);
                            listDtel.set(1, sre);
                        }
                    } else {
                        listDtel.add("");
                    }

                }
                if(tekSavvyProducts.containsKey(i)) {
                    String msqDownload = JSONUtils.getMQSDBSBDownloadSpeed(msqResponse.asPrettyString(), listDtel.get(0));
                    String msqUpload = JSONUtils.getMQSDBSBUploadSpeed(msqResponse.asPrettyString(), listDtel.get(1));
                    String msqProductId = JSONUtils.getMQSDBSBProductId(msqResponse.asPrettyString(), listDtel.get(0));
                    validateEqualsProducts(i+ " Download", listDtel.get(0), listDtel.get(0), String.valueOf(msqDownload), msqProductId);
                    validateEquals("Upload", listDtel.get(1), listDtel.get(1), String.valueOf(msqUpload));
                    tekSavvyProducts.remove(i);
                } else {
                    String msqDownload = JSONUtils.getMQSDBSBDownloadSpeed(msqResponse.asPrettyString(), listDtel.get(0));
                    String msqUpload = JSONUtils.getMQSDBSBUploadSpeed(msqResponse.asPrettyString(), listDtel.get(1));
                    String msqProductId = JSONUtils.getMQSDBSBProductId(msqResponse.asPrettyString(), listDtel.get(0));
                    validateEqualsProducts(i+" Download", listDtel.get(0), "", String.valueOf(msqDownload), msqProductId);
                    validateEquals("Upload", listDtel.get(1),"", String.valueOf(msqUpload));
                }
            }
        }



//        System.out.println("tek savvy Size : " +tekSavvyProducts.size());
        if(tekSavvyProducts.size()>0) {
            List<String> listTek;
            for (String i : tekSavvyProducts.keySet()){
//                System.out.println("ID : " + i + " Desc: " + tekSavvyProducts.get(i) );
                listTek = RegexUtils.getDownloadUploadSpeed(tekSavvyProducts.get(i));
                if (listTek == null) {
                    listTek = new ArrayList<>();
                    listTek.add("");
                    listTek.add("");
                } else {
                    if (Double.parseDouble(listTek.get(0)) < 1.00) {
                        Double d = Double.parseDouble(listTek.get(0)) * 1000;
                        String sre = String.valueOf(d.intValue());
                        listTek.set(0, sre);
                    } else {
                        Double d = Double.parseDouble(listTek.get(0));
                        int val = d.intValue();
                        String sre = String.valueOf(val);
                        listTek.set(0, sre);
                    }
                    if(listTek.size()>1) {
                        if (Double.parseDouble(listTek.get(1)) < 1.00) {
                            Double d = Double.parseDouble(listTek.get(1)) * 1000;
                            String sre = String.valueOf(d.intValue());
                            listTek.set(1, sre);
                        } else {
                            Double d = Double.parseDouble(listTek.get(1));
                            int val = d.intValue();
                            String sre = String.valueOf(val);
                            listTek.set(1, sre);
                        }
                    } else {
                        listTek.add("");
                    }

                }
                String msqDownload = JSONUtils.getMQSDBSBDownloadSpeed(msqResponse.asPrettyString(), listTek.get(0));
                String msqUpload = JSONUtils.getMQSDBSBUploadSpeed(msqResponse.asPrettyString(), listTek.get(1));
                String msqProductId = JSONUtils.getMQSDBSBProductId(msqResponse.asPrettyString(), listTek.get(0));
                validateEqualsProducts(i+" Download", "", listTek.get(0), String.valueOf(msqDownload), msqProductId);
                validateEquals("Upload", "", listTek.get(1), String.valueOf(msqUpload));

            }
        }

    }

    private static void validateEquals(String property, String dTelVal, String tekSavvyVal, String msqVal) {
        if (!StringUtils.isEmpty(dTelVal) && !StringUtils.isEmpty(tekSavvyVal) && !StringUtils.isEmpty(msqVal)) {
            if (dTelVal == tekSavvyVal && dTelVal.trim().equalsIgnoreCase(msqVal)) {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), msqVal, "Matched");
            } else if (dTelVal != tekSavvyVal && msqVal.contains(dTelVal) && msqVal.contains(tekSavvyVal)) {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), msqVal, "Matched");
            } else {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), msqVal, "Not Matched");
            }
        } else if(dTelVal.equals("0") && tekSavvyVal.equals("0")) {
            AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), msqVal, "Matched");
        } else if (!StringUtils.isEmpty(dTelVal) && !StringUtils.isEmpty(tekSavvyVal) && StringUtils.isEmpty(msqVal)) {
            AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), "", "Not Matched");
        } else if (StringUtils.isEmpty(dTelVal) && !StringUtils.isEmpty(tekSavvyVal) && StringUtils.isEmpty(msqVal)) {
            AssertionUtils.validateAPIResponse(property, "", tekSavvyVal.trim(), "", "Not Matched");
        } else if (!StringUtils.isEmpty(dTelVal) && StringUtils.isEmpty(tekSavvyVal) && StringUtils.isEmpty(msqVal)) {
            AssertionUtils.validateAPIResponse(property, dTelVal.trim(), "", "", "Not Matched");
        } else if (StringUtils.isEmpty(dTelVal) && !StringUtils.isEmpty(tekSavvyVal) && !StringUtils.isEmpty(msqVal)) {
            if (tekSavvyVal.trim().equalsIgnoreCase(msqVal)) {
                AssertionUtils.validateAPIResponse(property, "", tekSavvyVal.trim(), msqVal.trim(), "Matched");
            } else {
                AssertionUtils.validateAPIResponse(property, "", tekSavvyVal.trim(), msqVal.trim(), "Not Matched");
            }
        } else if (StringUtils.isEmpty(dTelVal) && StringUtils.isEmpty(tekSavvyVal) && !StringUtils.isEmpty(msqVal)) {
            AssertionUtils.validateAPIResponse(property, "", "", msqVal.trim(), "Matched");
        } else if (!StringUtils.isEmpty(dTelVal) && StringUtils.isEmpty(tekSavvyVal) && !StringUtils.isEmpty(msqVal)) {
            if (dTelVal.trim().equals(msqVal.trim())) {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), "", msqVal.trim(), "Matched");
            } else {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), "", msqVal.trim(), "Not Matched");
            }
        } else {
            AssertionUtils.validateAPIResponse(property, "", "", "", "Matched");
        }

    }

    private static void validateEqualsProducts(String property, String dTelVal, String tekSavvyVal, String msqVal, String productId) {
        String msqValProduct = msqVal + " " + productId;
        if (!StringUtils.isEmpty(dTelVal) && !StringUtils.isEmpty(tekSavvyVal) && !StringUtils.isEmpty(msqVal)) {
            if (dTelVal == tekSavvyVal && dTelVal.trim().equalsIgnoreCase(msqVal)) {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), msqValProduct, "Matched");
            } else if (dTelVal != tekSavvyVal && msqVal.contains(dTelVal) && msqVal.contains(tekSavvyVal)) {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), msqValProduct, "Matched");
            } else {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), msqValProduct, "Not Matched");
            }
        } else if(dTelVal.equals("0") && tekSavvyVal.equals("0")) {
            AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), msqValProduct, "Matched");
        } else if (!StringUtils.isEmpty(dTelVal) && !StringUtils.isEmpty(tekSavvyVal) && StringUtils.isEmpty(msqVal)) {
            AssertionUtils.validateAPIResponse(property, dTelVal.trim(), tekSavvyVal.trim(), "", "Not Matched");
        } else if (StringUtils.isEmpty(dTelVal) && !StringUtils.isEmpty(tekSavvyVal) && StringUtils.isEmpty(msqVal)) {
            AssertionUtils.validateAPIResponse(property, "", tekSavvyVal.trim(), "", "Not Matched");
        } else if (!StringUtils.isEmpty(dTelVal) && StringUtils.isEmpty(tekSavvyVal) && StringUtils.isEmpty(msqVal)) {
            AssertionUtils.validateAPIResponse(property, dTelVal.trim(), "", "", "Not Matched");
        } else if (StringUtils.isEmpty(dTelVal) && !StringUtils.isEmpty(tekSavvyVal) && !StringUtils.isEmpty(msqVal)) {
            if (tekSavvyVal.trim().equalsIgnoreCase(msqVal)) {
                AssertionUtils.validateAPIResponse(property, "", tekSavvyVal.trim(), msqValProduct, "Matched");
            } else {
                AssertionUtils.validateAPIResponse(property, "", tekSavvyVal.trim(), msqValProduct, "Not Matched");
            }
        } else if (StringUtils.isEmpty(dTelVal) && StringUtils.isEmpty(tekSavvyVal) && !StringUtils.isEmpty(msqVal)) {
            AssertionUtils.validateAPIResponse(property, "", "", msqValProduct, "Matched");
        } else if (!StringUtils.isEmpty(dTelVal) && StringUtils.isEmpty(tekSavvyVal) && !StringUtils.isEmpty(msqVal)) {
            if (dTelVal.trim().equals(msqVal.trim())) {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), "", msqValProduct, "Matched");
            } else {
                AssertionUtils.validateAPIResponse(property, dTelVal.trim(), "", msqValProduct, "Not Matched");
            }
        } else {
            AssertionUtils.validateAPIResponse(property, "", "", "", "Matched");
        }

    }
}
