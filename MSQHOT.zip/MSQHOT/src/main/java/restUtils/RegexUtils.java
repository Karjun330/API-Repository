package restUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexUtils {
    public static List<String> getDownloadUploadSpeed(String str) {
        List<String> list = new ArrayList<>();
        // extract speed from the response "Legacy 0.640 with 0.640 upload"
        Pattern p = Pattern.compile("\\d+\\.\\d+|\\d+");
        Matcher m = p.matcher(str);
        if(m.find()){
            list.add(m.group());
        }
        if(m.find()){
            list.add(m.group());
        }
        System.out.println(list.size());
        if(list.size()>0) {
            return list;
        }
       return null;
    }
}
