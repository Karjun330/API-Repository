package restUtils;

import com.aventstack.extentreports.markuputils.MarkupHelper;
import reporting.Setup;
import java.util.ArrayList;
import java.util.List;

public class AssertionUtils {

    private static List<AssertionKeys> actualValueMap = new ArrayList<>();

    public static void validateAPIResponse(String property, String dTelVal, String tekSavvyVal, String msqVal, String result) {
        actualValueMap.add(new AssertionKeys(property, dTelVal, tekSavvyVal, msqVal, result));
    }

    public  static void generateTableInReport(){
        String[][] finalAssertionMap = actualValueMap.stream().map(assertionKeys -> new String[] {assertionKeys.getProperty(), assertionKeys.getDTelValue(),assertionKeys.getTekSavvyValue(),assertionKeys.getMsqValue(),assertionKeys.getResult()}).toArray(String[][]::new);
        Setup.extentTest.get().info(MarkupHelper.createTable(finalAssertionMap,"table-sm"));
    }
    public static void generateTableHeadersInReports() {
        actualValueMap.add(new AssertionKeys("Property", "DTelValue", "TekSavvy_Value", "MQS2_Value", "Result"));
    }
    public static void clearTable() {
        actualValueMap.clear();
    }
}
