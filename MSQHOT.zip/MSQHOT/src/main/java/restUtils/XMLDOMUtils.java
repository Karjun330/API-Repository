package restUtils;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import java.io.IOException;
import java.io.StringReader;
import java.text.Normalizer;
import java.util.HashMap;
import java.util.Map;

public class XMLDOMUtils {
    public static Document stringToDOM(String xmlString) throws SAXException, ParserConfigurationException, IOException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = factory.newDocumentBuilder();
        return documentBuilder.parse(new InputSource(new StringReader(xmlString)));
    }

    public static String parseXML(Document doc, String expression) throws XPathExpressionException {
        XPathFactory xPathFactory = XPathFactory.newInstance();
        XPath xPath = xPathFactory.newXPath();
        XPathExpression xPathExpression = xPath.compile(expression);
        NodeList nodeList = (NodeList) xPathExpression.evaluate(doc, XPathConstants.NODESET);
        if (nodeList.item(0) != null) {
//            return nodeList.item(0).getTextContent();
            return Normalizer.normalize((nodeList.item(0).getTextContent()), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        }
        return "";

    }

    public static Map<String, String> parseGASRProductsXML(Document doc) throws XPathExpressionException {
        XPathFactory xPathFactory = XPathFactory.newInstance();
        XPath xPath = xPathFactory.newXPath();
        Map<String, String> productMap = new HashMap<>();
        XPathExpression productIdExpression = xPath.compile("//offering[contains(offeringID,'GASR')]/offeringID");
        XPathExpression productDescExpression = xPath.compile("//offering[contains(offeringID,'GASR')]/offeringDescription");
        NodeList productIdList = (NodeList) productIdExpression.evaluate(doc, XPathConstants.NODESET);
        NodeList productDescList = (NodeList) productDescExpression.evaluate(doc, XPathConstants.NODESET);


        if(productIdList!=null) {
            for (int i =0; i< productIdList.getLength(); i++) {
                productMap.put(productIdList.item(i).getTextContent(), productDescList.item(i).getTextContent());
            }
        }
        return productMap;

    }

    public static Map<String, String> parseGASBProductsXML(Document doc) throws XPathExpressionException {
        XPathFactory xPathFactory = XPathFactory.newInstance();
        XPath xPath = xPathFactory.newXPath();
        Map<String, String> productMap = new HashMap<>();
        XPathExpression productIdExpression = xPath.compile("//offering[contains(offeringID,'GASB')]/offeringID");
        XPathExpression productDescExpression = xPath.compile("//offering[contains(offeringID,'GASB')]/offeringDescription");
        NodeList productIdList = (NodeList) productIdExpression.evaluate(doc, XPathConstants.NODESET);
        NodeList productDescList = (NodeList) productDescExpression.evaluate(doc, XPathConstants.NODESET);


        if(productIdList!=null) {
            for (int i =0; i< productIdList.getLength(); i++) {
                productMap.put(productIdList.item(i).getTextContent(), productDescList.item(i).getTextContent());
            }
        }
        return productMap;

    }

    public static Map<String, String> parseDBSRProductsXML(Document doc) throws XPathExpressionException {
        XPathFactory xPathFactory = XPathFactory.newInstance();
        XPath xPath = xPathFactory.newXPath();
        Map<String, String> productMap = new HashMap<>();
        XPathExpression productIdExpression = xPath.compile("//offering[contains(offeringID,'DBSR')]/offeringID");
        XPathExpression productDescExpression = xPath.compile("//offering[contains(offeringID,'DBSR')]/offeringDescription");
        NodeList productIdList = (NodeList) productIdExpression.evaluate(doc, XPathConstants.NODESET);
        NodeList productDescList = (NodeList) productDescExpression.evaluate(doc, XPathConstants.NODESET);


        if(productIdList!=null) {
            for (int i =0; i< productIdList.getLength(); i++) {
                productMap.put(productIdList.item(i).getTextContent(), productDescList.item(i).getTextContent());
            }
        }
        return productMap;

    }


    public static Map<String, String> parseDBSBProductsXML(Document doc) throws XPathExpressionException {
        XPathFactory xPathFactory = XPathFactory.newInstance();
        XPath xPath = xPathFactory.newXPath();
        Map<String, String> productMap = new HashMap<>();
        XPathExpression productIdExpression = xPath.compile("//offering[contains(offeringID,'DBSB')]/offeringID");
        XPathExpression productDescExpression = xPath.compile("//offering[contains(offeringID,'DBSB')]/offeringDescription");
        NodeList productIdList = (NodeList) productIdExpression.evaluate(doc, XPathConstants.NODESET);
        NodeList productDescList = (NodeList) productDescExpression.evaluate(doc, XPathConstants.NODESET);


        if(productIdList!=null) {
            for (int i =0; i< productIdList.getLength(); i++) {
                productMap.put(productIdList.item(i).getTextContent(), productDescList.item(i).getTextContent());
            }
        }
        return productMap;

    }

    public static Map<String, String> getNumberOfGASRProductsFromXML(Document doc, String expression) throws XPathExpressionException {
        Map<String, String> productmap = new HashMap<>();
        doc.getDocumentElement().normalize();
        NodeList productList = doc.getElementsByTagName("offering");
        if (productList.getLength() > 0) {
            for (int i = 0; i < productList.getLength(); i++) {
                Node productNode = productList.item(i);
                if (productNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element productElement = (Element) productNode;
                    String productId = productElement.getElementsByTagName("offeringID").item(0).getTextContent();
                    if (productId.contains("GASR")) {
                        productmap.put(productElement.getElementsByTagName("offeringID").item(0).getTextContent(), productElement.getElementsByTagName("offeringDescription").item(0).getTextContent());
                    }
                }
            }
            return productmap;
        } else {
            return null;
        }
    }
}
