package restUtils;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.JsonPath;

import java.text.Normalizer;

public class JSONUtils {
    public  static String parseJSON(String json, String path) {
        Gson gson = new Gson();
        JsonElement jsonElement = JsonParser.parseString(json);
        Object jsonObject = gson.fromJson(jsonElement, Object.class);
        try {
            String str = JsonPath.read(jsonObject, path).toString();
            if (str.length()>0) {
                return Normalizer.normalize(str, Normalizer.Form.NFD).replaceAll("\\p{M}","");
            }
        } catch (Exception e) {
            return "";
        }
        return "";
    }

    public static String getMQSGASRDownloadSpeed(String msqResponse, String speed) {
        String msqDownloadPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='GAS - Residential')].speedDetails.speedList.speed[?(@.downloadSpeed==" + speed + " )].downloadSpeed";
        String msqDownload = JSONUtils.parseJSON(msqResponse, msqDownloadPath);

        if (msqDownload.contains("[")) {
            String[] str = msqDownload.replace("[", "").replace(".0]", "").replace(".0", "").replace("]", "").split(",");
            return str[0];
        }
        return "";
    }

    public static String getMQSGASRUploadSpeed(String msqResponse, String speed) {
        String msqUploadPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='GAS - Residential')].speedDetails.speedList.speed[?(@.uploadSpeed==" + speed + " )].uploadSpeed";
        String msqUpload = JSONUtils.parseJSON(msqResponse, msqUploadPath);
        if (msqUpload.contains("[")) {
            String[] str = msqUpload.replace("[", "").replace(".0]", "").replace(".0", "").replace("]", "").split(",");
            return str[0];
        }
        return  "";
    }

    public static String getMQSGASRProductId(String msqResponse, String speed) {
        String msqProductIdPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='GAS - Residential' && @.speedDetails.speedList.speed[0].downloadSpeed=='"+speed+"')].productOfferingID";
        String msqProductId = JSONUtils.parseJSON(msqResponse, msqProductIdPath);
        if (msqProductId!=null) {
            String[] str = msqProductId.replace("[","").replace("]","").split(",");
            return str[0];
        }
        return "";
    }

    public static String getMQSGASBDownloadSpeed(String msqResponse, String speed) {
        String msqDownloadPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='GAS - Business')].speedDetails.speedList.speed[?(@.downloadSpeed==" + speed + " )].downloadSpeed";
        String msqDownload = JSONUtils.parseJSON(msqResponse, msqDownloadPath);
        if (msqDownload.contains("[")) {
            String[] str = msqDownload.replace("[", "").replace(".0]", "").replace(".0", "").replace("]", "").split(",");
            return str[0];
        }
        return "";
    }

    public static String getMQSGASBUploadSpeed(String msqResponse, String speed) {
        String msqUploadPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='GAS - Business')].speedDetails.speedList.speed[?(@.uploadSpeed==" + speed + " )].uploadSpeed";
        String msqUpload = JSONUtils.parseJSON(msqResponse, msqUploadPath);
        if (msqUpload.contains("[")) {
            String[] str = msqUpload.replace("[", "").replace(".0]", "").replace(".0", "").replace("]", "").split(",");
            return str[0];
        }
        return  "";
    }

    public static String getMQSGASBProductId(String msqResponse, String speed) {
        String msqProductIdPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='GAS - Business' && @.speedDetails.speedList.speed[0].downloadSpeed=='"+speed+"')].productOfferingID";
        String msqProductId = JSONUtils.parseJSON(msqResponse, msqProductIdPath);
        if (msqProductId!=null) {
            String[] str = msqProductId.replace("[","").replace("]","").split(",");
            return str[0];
        }
        return "";
    }

    public static String getMQSDBSRDownloadSpeed(String msqResponse, String speed) {
        String msqDownloadPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='DBS - Residential')].speedDetails.speedList.speed[?(@.downloadSpeed==" + speed + " )].downloadSpeed";
        String msqDownload = JSONUtils.parseJSON(msqResponse, msqDownloadPath);
        if (msqDownload.contains("[")) {
            String[] str = msqDownload.replace("[", "").replace(".0]", "").replace(".0", "").replace("]", "").split(",");
            return str[0];
        }
        return "";
    }

    public static String getMQSDBSRUploadSpeed(String msqResponse, String speed) {
        String msqUploadPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='DBS - Residential')].speedDetails.speedList.speed[?(@.uploadSpeed==" + speed + " )].uploadSpeed";
        String msqUpload = JSONUtils.parseJSON(msqResponse, msqUploadPath);
        if (msqUpload.contains("[")) {
            String[] str = msqUpload.replace("[", "").replace(".0]", "").replace(".0", "").replace("]", "").split(",");
            return str[0];
        }
        return  "";
    }

    public static String getMQSDBSRProductId(String msqResponse, String speed) {
        String msqProductIdPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='DBS - Residential' && @.speedDetails.speedList.speed[0].downloadSpeed=='"+speed+"')].productOfferingID";
        String msqProductId = JSONUtils.parseJSON(msqResponse, msqProductIdPath);
        if (msqProductId!=null) {
            String[] str = msqProductId.replace("[","").replace("]","").split(",");
            return str[0];
        }
        return "";
    }

    public static String getMQSDBSBDownloadSpeed(String msqResponse, String speed) {
        String msqDownloadPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='DBS - Business')].speedDetails.speedList.speed[?(@.downloadSpeed==" + speed + " )].downloadSpeed";

        String msqDownload = JSONUtils.parseJSON(msqResponse, msqDownloadPath);
        if (msqDownload.contains("[")) {
            String[] str = msqDownload.replace("[", "").replace(".0]", "").replace(".0", "").replace("]", "").split(",");
            return str[0];
        }
        return "";
    }

    public static String getMQSDBSBUploadSpeed(String msqResponse, String speed) {
        String msqUploadPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='DBS - Business')].speedDetails.speedList.speed[?(@.uploadSpeed==" + speed + " )].uploadSpeed";
        String msqUpload = JSONUtils.parseJSON(msqResponse, msqUploadPath);
        if (msqUpload.contains("[")) {
            String[] str = msqUpload.replace("[", "").replace(".0]", "").replace(".0", "").replace("]", "").split(",");
            return str[0];
        }
        return  "";
    }

    public static String getMQSDBSBProductId(String msqResponse, String speed) {
        String msqProductIdPath = "$.locationMatches.locationMatch[0].productList.products[?(@.productOption=='DBS - Business' && @.speedDetails.speedList.speed[0].downloadSpeed=='"+speed+"')].productOfferingID";
        String msqProductId = JSONUtils.parseJSON(msqResponse, msqProductIdPath);
        if (msqProductId!=null) {
            String[] str = msqProductId.replace("[","").replace("]","").split(",");
            return str[0];
        }
        return "";
    }
}
