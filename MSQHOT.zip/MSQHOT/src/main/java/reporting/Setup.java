package reporting;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import config.FrameworkConfig;
import org.aeonbits.owner.ConfigFactory;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import restUtils.AssertionUtils;
import java.util.Arrays;

public class Setup implements ITestListener {

    public static ExtentReports extentReports ;
    public  static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    static FrameworkConfig config = ConfigFactory.create(FrameworkConfig.class);
    public  static String address;

    @Override
    public void onStart(ITestContext context) {
        address = "";
        String fileName = ExtentReportManager.getReportNameWithTimeStamp();
        String fullReportPath = System.getProperty("user.dir") + "\\reports\\" + fileName;
         extentReports = ExtentReportManager.createInstance(fullReportPath, "MappingReport","API Mapping Report");
        System.out.println("**** Path: " + fullReportPath);
    }

    @Override
    public void onFinish(ITestContext context) {
        if(extentReports != null) {
            extentReports.flush();
            AssertionUtils.clearTable();
        }
    }

    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest test = extentReports.createTest("Test Address: " + address);
        AssertionUtils.clearTable();
        extentTest.set(test);
    }

    @Override
    public void onTestFailure(ITestResult result) {
        ExtentReportManager.logFailureDetails(result.getThrowable().getMessage());
        String stackTrace = Arrays.toString(result.getThrowable().getStackTrace());
        stackTrace = stackTrace.replaceAll(",", "<br>");
        String formattedTrace = "<details>\n" +
                "    <summary>Click Here to See Exception logs</summary>" +
                "    " + stackTrace + "\n" +
                "</details>\n";
        ExtentReportManager.logExceptionDetails(formattedTrace);

    }

}
