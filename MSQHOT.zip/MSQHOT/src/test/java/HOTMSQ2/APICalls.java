package HOTMSQ2;

import config.FrameworkConfig;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.SpecificationQuerier;
import org.aeonbits.owner.ConfigFactory;
import reporting.ExtentReportManager;
import reporting.Setup;


public class APICalls {
    static FrameworkConfig config = ConfigFactory.create(FrameworkConfig.class);
    public  static RequestSpecification getHotsRequestSpecification(String soapPayload) {
        return RestAssured.given()
                .baseUri(config.hotsUri())
                .header("Content-Type","text/xml")
                .body(soapPayload)
                .auth().basic(config.hotsUserName(), config.hotPassword());
    }

    public  static RequestSpecification getMSQRequestSpecification(String soapPayload) {
        return RestAssured.given()
                .baseUri(config.msqUri())
                .contentType(ContentType.JSON)
                .body(soapPayload)
                .auth().basic(config.msqUserName(), config.msqPassword());
    }
    private static void printHOTSRequestLogsInReport(RequestSpecification requestSpecification) {
        QueryableRequestSpecification queryableRequestSpecification = SpecificationQuerier.query(requestSpecification);
        ExtentReportManager.logInfoDetails("ENDPOINT: " + queryableRequestSpecification.getBaseUri());
    }

    private static void printHOTSResponseLogsInReport(Response response) {
        ExtentReportManager.logInfoDetails("RESPONSE STATUS CODE: " + response.getStatusCode());
        ExtentReportManager.logXMLResponse(response.prettyPrint());
    }

    private static void printMSQRequestLogsInReport(RequestSpecification requestSpecification, String address) {
        QueryableRequestSpecification queryableRequestSpecification = SpecificationQuerier.query(requestSpecification);
        ExtentReportManager.logInfoDetails("Address: " + address);
        ExtentReportManager.logInfoDetails("ENDPOINT: " + queryableRequestSpecification.getBaseUri());
    }

    private static void printMSQResponseLogsInReport(Response response) {
        ExtentReportManager.logInfoDetails("RESPONSE STATUS CODE: " + response.getStatusCode());
        String stackTrace = response.getBody().prettyPrint();
        String formattedTrace = "<details>\n" +
                "    <summary>Click Here to See MSQ2 Response</summary>" +
                "    " + stackTrace + "\n" +
                "</details>\n";
        Setup.extentTest.get().info(formattedTrace);
    }

    public static Response performMSQPost(String address) {
        String soapPayload = GeneratePayloads.generateMSQ2PayLoad(address);
        RestAssured.useRelaxedHTTPSValidation();
        RequestSpecification requestSpecification = getMSQRequestSpecification(soapPayload);
        Response response = requestSpecification.post();
        printMSQRequestLogsInReport(requestSpecification, address);
        printMSQResponseLogsInReport(response);
        return response;
    }

    public static Response performDTelPost(String streetNumber, String streetName, String streetType, String streetDirection, String municipalityCity, String provinceOrState, String postalCode) {
        String soapPayload = GeneratePayloads.generateDTelPayLoad(streetNumber, streetName, streetType, streetDirection, municipalityCity, provinceOrState, postalCode);
        RequestSpecification requestSpecification = getHotsRequestSpecification(soapPayload);
        Response response = requestSpecification.post();
        printHOTSRequestLogsInReport(requestSpecification);
        printHOTSResponseLogsInReport(response);
        return response;
    }

    public static Response performTekSavvyPost(String streetNumber, String streetName, String streetType, String streetDirection, String municipalityCity, String provinceOrState, String postalCode) {
        String soapPayload = GeneratePayloads.generateTekSavvyPayLoad(streetNumber, streetName, streetType, streetDirection, municipalityCity, provinceOrState, postalCode);
        RequestSpecification requestSpecification = getHotsRequestSpecification(soapPayload);
        Response response = requestSpecification.post();
        printHOTSRequestLogsInReport(requestSpecification);
        printHOTSResponseLogsInReport(response);
        return response;
    }
}
