package HOTMSQ2;

import io.restassured.response.Response;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.xml.sax.SAXException;
import reporting.Setup;
import restUtils.ValidatedResponses;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;


public class APITest extends APICalls {

    @DataProvider(name = "excelData")
    public Iterator<Object[]> excelData() throws IOException {
        return new ExcelDataProvider("src/main/resources/HOTSADDress.xlsx", "Sheet4");
    }


    @BeforeMethod
    public void initializeTest(Object[] testArgs) {
        System.out.println("******BEFORE*****");
        Setup.address=testArgs[7].toString();
    }

    @Test(dataProvider = "excelData")
    public void hotsMSQAPI(String streetNumber, String streetName, String streetType, String streetDirection, String municipalityCity, String provinceOrState, String postalCode, String address) throws IOException, XPathExpressionException, ParserConfigurationException, SAXException {

        Response mSQResponse = performMSQPost(address);
        Response dTelResponse = performDTelPost(streetNumber, streetName, streetType, streetDirection, municipalityCity, provinceOrState, postalCode);
        Response tekSavvyResponse = performTekSavvyPost(streetNumber, streetName, streetType, streetDirection, municipalityCity, provinceOrState, postalCode);
        ValidatedResponses.validateAllVerificationPoints(dTelResponse, tekSavvyResponse, mSQResponse);
    }


    private static class ExcelDataProvider implements Iterator<Object[]> {
        private final Iterator<Row> rowIterator;

        public ExcelDataProvider(String excelPath, String sheetName) throws IOException {
            FileInputStream fileInputStream = new FileInputStream(excelPath);
            Workbook workbook = new XSSFWorkbook(fileInputStream);
            Sheet sheet = workbook.getSheet(sheetName);
            this.rowIterator = sheet.iterator();
            this.rowIterator.next(); // skip heading row
        }

        @Override
        public boolean hasNext() {
            return rowIterator.hasNext();
        }

        @Override
        public Object[] next() {
            Row row = rowIterator.next();
            return new Object[]{
                    row.getCell(0).getStringCellValue(),
                    row.getCell(1).getStringCellValue(),
                    row.getCell(2).getStringCellValue(),
                    row.getCell(3).getStringCellValue(),
                    row.getCell(4).getStringCellValue(),
                    row.getCell(5).getStringCellValue(),
                    row.getCell(6).getStringCellValue(),
                    row.getCell(7).getStringCellValue(),
            };

        }
    }
}

