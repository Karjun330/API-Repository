package HOTMSQ2;

public class GeneratePayloads {

    public  static  String generateDTelPayLoad(String streetNumber, String streetName, String streetType, String streetDirection, String municipalityCity, String provinceOrState, String postalCode) {
        return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:ca.bell.ots.productqualificationservice\">\n" +
                "   <soapenv:Header/>\n" +
                "   <soapenv:Body>\n" +
                "      <urn:getPresaleProducts>\n" +
                "         <requestHeader>\n" +
                "            <serviceConsumer>Communication TELOSysteme Inc</serviceConsumer>\n" +
                "            <serviceRequestUserId>DistributelOrdering</serviceRequestUserId>\n" +
                "         </requestHeader>\n" +
                "         <customerInfo>\n" +
                "            <serviceRequestInfo>\n" +
                "               <addressQueryDetail>\n" +
                "                  <address>\n" +
                "                       <streetNumber>" + streetNumber + "</streetNumber>\n" +
                "                     <streetName>" + streetName + "</streetName>\n" +
                "                     <streetType>" + streetType + "</streetType>\n" +
                "                     <streetDirection>" + streetDirection + "</streetDirection>\n" +
                "                     <municipalityCity>" + municipalityCity + "</municipalityCity>\n" +
                "                     <provinceOrState>" + provinceOrState + "</provinceOrState>\n" +
                "                     <postalCode>" + postalCode + "</postalCode>\n" +
                "                  </address>\n" +
                "               </addressQueryDetail>\n" +
                "            </serviceRequestInfo>\n" +
                "         </customerInfo>\n" +
                "      </urn:getPresaleProducts>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>";
    }

    public  static  String generateTekSavvyPayLoad(String streetNumber, String streetName, String streetType, String streetDirection, String municipalityCity, String provinceOrState, String postalCode) {
        return "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:ca.bell.ots.productqualificationservice\">\n" +
                "   <soapenv:Header/>\n" +
                "   <soapenv:Body>\n" +
                "      <urn:getPresaleProducts>\n" +
                "         <requestHeader>\n" +
                "            <serviceConsumer>TekSavvy Solutions Inc.</serviceConsumer>\n" +
                "            <serviceRequestUserId>TekSavvy</serviceRequestUserId>\n" +
                "         </requestHeader>\n" +
                "         <customerInfo>\n" +
                "            <serviceRequestInfo>\n" +
                "               <addressQueryDetail>\n" +
                "                  <address>\n" +
                "                       <streetNumber>" + streetNumber + "</streetNumber>\n" +
                "                     <streetName>" + streetName + "</streetName>\n" +
                "                     <streetType>" + streetType + "</streetType>\n" +
                "                     <streetDirection>" + streetDirection + "</streetDirection>\n" +
                "                     <municipalityCity>" + municipalityCity + "</municipalityCity>\n" +
                "                     <provinceOrState>" + provinceOrState + "</provinceOrState>\n" +
                "                     <postalCode>" + postalCode + "</postalCode>\n" +
                "                  </address>\n" +
                "               </addressQueryDetail>\n" +
                "            </serviceRequestInfo>\n" +
                "         </customerInfo>\n" +
                "      </urn:getPresaleProducts>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>";
    }

    public  static  String generateMSQ2PayLoad(String address) {
        return "{\n" +
                "\n" +
                "   \"senderCompanyName\" : \"bell\",\n" +
                "\n" +
                "   \"senderApp\" : \"malibu\",\n" +
                "\n" +
                "   \"senderChannel\" : \"prod\",\n" +
                "\n" +
                "   \"language\" : \"English\",\n" +
                "\n" +
                "   \"showUnavailableProducts\" : 0,\n" +
                "\n" +
                "   \"returnSourceAddressFlag\" : 1,\n" +
                "\n" +
                "   \"returnNetworkAttributesFlag\" : 0,\n" +
                "\n" +
                "   \"returnFttxAttributesFlag\" : 1,\n" +
                "\n" +
                "   \"returnWirelessAttributesFlag\" : 0,\n" +
                "\n" +
                "   \"rollupProductsFlag\" : 0,\n" +
                "\n" +
                "   \"useFTTXCapabilitiesOnlyFlag\": 1,\n" +
                "\n" +
                "   \"fullAddressLine\" : \"" + address + "\",\n" +
                "\n" +
                "   \"productName\" : [\n" +
                "\n" +
                "        \"Disaggregated Broadband Service\",\n" +
                "\n" +
                "        \"Gateway Access Service\",\n" +
                "\n" +
                "        \"High Speed Access\"\n" +
                "\n" +
                "   ]\n" +
                "\n" +
                "}";
    }
}
